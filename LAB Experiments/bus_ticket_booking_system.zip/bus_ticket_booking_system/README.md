# Triply Bus Ticket Booking System

A PHP/MySQL XAMPP Internet Programming lab project.

## Setup
1. Extract into `C:\xampp\htdocs\bus_ticket_booking_system`
2. Start Apache and MySQL in XAMPP.
3. Open `http://localhost/bus_ticket_booking_system/`
4. The database `bus_ticket_booking` and sample data are created automatically.

## Admin
URL: `/admin/login.php`
Email: `admin@triply.local`
Password: `admin123`

## User features
Registration, login, forgot/reset password demo, profile editing, route/date/passenger search, seat selection, passenger details, demo payment, confirmation, booking history, modification/cancellation rules, reviews/comments, news.

## Admin features
Bus categories, bus information, seats/fare management, booking modification/cancellation, registered users, news, reports.

## Payment/email
This is a lab/demo system. Payment is simulated and no card data is stored. Confirmation is shown on screen; production email can be connected through SMTP/PHPMailer.
