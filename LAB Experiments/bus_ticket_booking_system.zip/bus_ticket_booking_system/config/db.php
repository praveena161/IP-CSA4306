<?php
session_start();
$host = 'localhost'; $user = 'root'; $pass = ''; $db = 'bus_ticket_booking';
$conn = @new mysqli($host, $user, $pass);
if ($conn->connect_error) die("MySQL connection failed: ".$conn->connect_error);
$conn->set_charset("utf8mb4");
$conn->query("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db($db);
function esc($v){ global $conn; return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function go($url){ header("Location: $url"); exit; }
function flash($type,$msg){ $_SESSION['flash']=['type'=>$type,'msg'=>$msg]; }
function csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function check_csrf(){ if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')){ http_response_code(419); exit('Invalid request token.'); } }
function logged(){ return !empty($_SESSION['user']); }
function admin(){ return !empty($_SESSION['admin']); }
function require_login(){ if(!logged()) go('login.php'); }
function require_admin(){ if(!admin()) go('login.php'); }
function current_user(){ return $_SESSION['user']??null; }
function setup_db(){
 global $conn;
 $sql = [
 "CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120),email VARCHAR(160) UNIQUE,password VARCHAR(255),phone VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80),description TEXT,image VARCHAR(500),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS buses(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT,name VARCHAR(150),operator VARCHAR(120),bus_type VARCHAR(80),source VARCHAR(120),destination VARCHAR(120),travel_date DATE,departure TIME,arrival TIME,fare DECIMAL(10,2),total_seats INT,available_seats INT,description TEXT,image VARCHAR(500),status VARCHAR(20) DEFAULT 'Active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL)",
 "CREATE TABLE IF NOT EXISTS bookings(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,bus_id INT,booking_ref VARCHAR(30) UNIQUE,seat_count INT,seat_numbers VARCHAR(255),passenger_details TEXT,total_amount DECIMAL(10,2),payment_status VARCHAR(30) DEFAULT 'Paid',status VARCHAR(30) DEFAULT 'Confirmed',booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(bus_id) REFERENCES buses(id) ON DELETE CASCADE)",
 "CREATE TABLE IF NOT EXISTS comments(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,bus_id INT,rating INT DEFAULT 5,comment TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(bus_id) REFERENCES buses(id) ON DELETE CASCADE)",
 "CREATE TABLE IF NOT EXISTS news(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200),body TEXT,image VARCHAR(500),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS password_resets(id INT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(160),token VARCHAR(100),expires_at DATETIME,used TINYINT DEFAULT 0)"
 ];
 foreach($sql as $q) $conn->query($q);
 $c=$conn->query("SELECT COUNT(*) n FROM categories")->fetch_assoc()['n'];
 if(!$c){
   $cats=[['Volvo','Premium AC coaches with reclining seats','https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=900'],['Sleeper Coach','Comfortable sleeper buses for overnight routes','https://images.unsplash.com/photo-1570125909232-eb263c188f7e?w=900'],['AC Coach','Affordable air-conditioned intercity travel','https://images.unsplash.com/photo-1465447142348-e9952c393450?w=900'],['Express','Fast point-to-point city and regional service','https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=900']];
   $st=$conn->prepare("INSERT INTO categories(name,description,image) VALUES(?,?,?)");
   foreach($cats as $x){$st->bind_param("sss",$x[0],$x[1],$x[2]);$st->execute();}
 }
 $b=$conn->query("SELECT COUNT(*) n FROM buses")->fetch_assoc()['n'];
 if(!$b){
   $dates=[date('Y-m-d',strtotime('+1 day')),date('Y-m-d',strtotime('+2 day')),date('Y-m-d',strtotime('+3 day')),date('Y-m-d',strtotime('+4 day')),date('Y-m-d',strtotime('+5 day'))];
   $seed=[
   [1,'Skyline Volvo','BlueLine Travels','Volvo','Chennai','Bengaluru',$dates[0],'06:30:00','12:45:00',899,40,'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1200'],
   [2,'Night Rider Sleeper','Royal Roadways','Sleeper Coach','Bengaluru','Hyderabad',$dates[1],'21:00:00','07:00:00',1299,30,'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?w=1200'],
   [3,'Coastal AC','South Star','AC Coach','Chennai','Pondicherry',$dates[2],'08:00:00','11:15:00',499,45,'https://images.unsplash.com/photo-1465447142348-e9952c393450?w=1200'],
   [4,'City Express','MetroBus','Express','Hyderabad','Vijayawada',$dates[3],'07:15:00','12:30:00',699,42,'https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=1200'],
   [1,'Morning Volvo','BlueLine Travels','Volvo','Bengaluru','Chennai',$dates[4],'07:00:00','13:30:00',949,40,'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1200'],
   [3,'Deccan AC','South Star','AC Coach','Pune','Mumbai',$dates[1],'10:00:00','14:30:00',549,45,'https://images.unsplash.com/photo-1465447142348-e9952c393450?w=1200']];
   $st=$conn->prepare("INSERT INTO buses(category_id,name,operator,bus_type,source,destination,travel_date,departure,arrival,fare,total_seats,available_seats,image) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
   foreach($seed as $x){$a=40;$st->bind_param("issssssssdiss",$x[0],$x[1],$x[2],$x[3],$x[4],$x[5],$x[6],$x[7],$x[8],$x[9],$x[10],$a,$x[11]);$st->execute();}
 }
 if(!$conn->query("SELECT COUNT(*) n FROM news")->fetch_assoc()['n']){
   $conn->query("INSERT INTO news(title,body,image) VALUES
   ('Monsoon travel sale','Save up to 20% on selected routes this month.','https://images.unsplash.com/photo-1500534623283-312aade485b7?w=1000'),
   ('New sleeper routes','Overnight sleeper services are now available between major cities.','https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1000')");
 }
}
setup_db();
?>