<?php
require_once __DIR__.'/config/db.php';
function header_html($title='Triply'){
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=esc($title)?> · Triply Bus</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css"></head><body>
<header class="top"><a class="brand" href="index.php"><span class="logo">T</span><span>triply</span></a><nav>
<a href="index.php">Search</a><a href="buses.php">Buses</a><a href="news.php">News</a>
<?php if(logged()): ?>
<a href="dashboard.php">My trips</a><a href="profile.php">Profile</a><a class="outline" href="logout.php">Logout</a>
<?php else: ?>
<a href="login.php">Login</a><a class="btn small" href="register.php">Create account</a>
<?php endif; ?>
<?php if(admin()): ?><a class="adminlink" href="admin/index.php">Admin</a><?php endif; ?>
</nav></header><main>
<?php
if(!empty($_SESSION['flash'])){
  $f=$_SESSION['flash']; unset($_SESSION['flash']);
  echo '<div class="flash '.esc($f['type']).'">'.esc($f['msg']).'</div>';
}
}
function footer_html(){
?>
</main><footer><div><strong>triply</strong><p>Simple, safe bus travel for every journey.</p></div>
<div><a href="news.php">News</a><a href="index.php#help">Help</a><a href="admin/login.php">Admin</a></div>
<p class="copy">© <?=date('Y')?> Triply Bus Booking</p></footer></body></html>
<?php
}
?>