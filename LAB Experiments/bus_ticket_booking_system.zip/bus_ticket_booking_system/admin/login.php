<?php
require '../config/db.php';
if(admin()) go('index.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
    check_csrf();
    if($_POST['email']=='admin@triply.local' && $_POST['password']=='admin123'){
        $_SESSION['admin']=true;
        go('index.php');
    }
    flash('error','Invalid admin credentials.');
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin login · Triply</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="formwrap">
<div class="chip">ADMIN CONSOLE</div><h1>Triply control room</h1>
<p class="muted">Manage routes, buses, bookings, users, news and reports.</p>
<?php if(!empty($_SESSION['flash'])){$f=$_SESSION['flash'];unset($_SESSION['flash']);?>
<div class="flash error"><?=esc($f['msg'])?></div>
<?php } ?>
<form method="post"><input type="hidden" name="csrf" value="<?=csrf()?>">
<div class="field"><label>Email</label><input type="email" name="email" value="admin@triply.local" required></div><br>
<div class="field"><label>Password</label><input type="password" name="password" value="admin123" required></div><br>
<button class="btn">Login as admin</button></form>
<p><a href="../index.php">← Back to site</a></p>
</div></body></html>