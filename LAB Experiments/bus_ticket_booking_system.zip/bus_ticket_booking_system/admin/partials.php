<?php
require_once __DIR__.'/../config/db.php';
require_admin();
function ah($title){
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=esc($title)?> · Triply Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Plus+Jakarta+Sans:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css"></head><body>
<header class="top"><a class="brand" href="index.php"><span class="logo">T</span>triply <small style="color:#3157e7">ADMIN</small></a><nav>
<a href="../index.php">View site</a><a href="index.php">Dashboard</a><a href="buses.php">Buses</a><a href="categories.php">Categories</a><a href="bookings.php">Bookings</a><a href="users.php">Users</a><a href="news.php">News</a><a class="outline" href="../logout.php">Logout</a>
</nav></header>
<div class="adminnav"><a href="index.php">Overview</a><a href="buses.php">Bus information</a><a href="categories.php">Bus categories</a><a href="bookings.php">Bookings</a><a href="users.php">Registered users</a><a href="reports.php">Reports</a></div><main>
<?php
if(!empty($_SESSION['flash'])){
  $f=$_SESSION['flash']; unset($_SESSION['flash']);
  echo '<div class="flash '.esc($f['type']).'">'.esc($f['msg']).'</div>';
}
}
function af(){
?>
</main></body></html>
<?php } ?>