<?php
require '../database.php';
require_admin();
$q=trim($_GET['q']??'');
if($q!==''){
    $like="%$q%";
    $s=$conn->prepare("SELECT * FROM messages WHERE name LIKE ? OR email LIKE ? OR message LIKE ? ORDER BY id DESC");
    $s->bind_param("sss",$like,$like,$like);$s->execute();$rows=$s->get_result();
}else $rows=$conn->query("SELECT * FROM messages ORDER BY id DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Messages — LibraryHub</title><link rel="stylesheet" href="../style.css"></head><body>
<header><a class="brand" href="dashboard.php"><span class="logo">L</span> LibraryHub <small class="admin-label">ADMIN</small></a><button class="menu-toggle">☰</button><nav><a href="dashboard.php">Dashboard</a><a href="books.php">Books</a><a href="students.php">Students</a><a href="issues.php">Requests</a><a class="active" href="messages.php">Messages</a><a class="nav-cta" href="../logout.php">Logout</a></nav></header>
<main class="container page"><div class="page-title"><div><span class="eyebrow">SUPPORT</span><h1>Messages</h1><p>Messages submitted through the library contact form.</p></div></div>
<form class="searchbar compact-search" method="get"><div class="search-input">⌕<input name="q" value="<?=e($q)?>" placeholder="Search name, email or message"></div><button class="btn">Search</button><?php if($q):?><a class="btn ghost" href="messages.php">Clear</a><?php endif;?></form>
<div class="panel table-wrap"><table><thead><tr><th>From</th><th>Message</th><th>Sent</th></tr></thead><tbody><?php while($m=$rows->fetch_assoc()):?><tr><td><strong><?=e($m['name'])?></strong><br><a href="mailto:<?=e($m['email'])?>"><?=e($m['email'])?></a></td><td><?=nl2br(e($m['message']))?></td><td><?=e($m['created_at'])?></td></tr><?php endwhile;?></tbody></table><?php if($rows->num_rows===0):?><div class="empty compact"><h3>No messages</h3><p>There are no contact messages yet.</p></div><?php endif;?></div></main><footer>LibraryHub Admin</footer><script src="../script.js"></script></body></html>
