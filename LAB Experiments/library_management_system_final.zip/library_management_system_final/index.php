<?php require 'database.php';
$totalBooks=$conn->query("SELECT COUNT(*) n FROM books")->fetch_assoc()['n'];
$available=$conn->query("SELECT COALESCE(SUM(available),0) n FROM books")->fetch_assoc()['n'];
$totalUsers=$conn->query("SELECT COUNT(*) n FROM users")->fetch_assoc()['n'];
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LibraryHub — College Library</title><link rel="stylesheet" href="style.css"></head><body>
<header><a class="brand" href="index.php"><span class="logo">L</span> LibraryHub</a><button class="menu-toggle" aria-label="Toggle menu">☰</button><nav>
<a class="<?=active('index.php')?>" href="index.php">Home</a><a href="books.php">Catalog</a><a href="contact.php">Contact</a>
<?php if(!empty($_SESSION['user_id'])): ?><a href="my_books.php">My Books</a><a class="nav-cta" href="logout.php">Logout</a><?php else: ?><a href="login.php">Login</a><a class="nav-cta" href="register.php">Get Started</a><?php endif; ?>
<a class="admin-link" href="admin/login.php">Admin</a></nav></header>
<main>
<section class="hero container"><div class="hero-copy"><span class="eyebrow">COLLEGE LIBRARY • DIGITAL ACCESS</span><h1>Find your next <span>great read.</span></h1><p>Search the collection, request available books, and keep track of every loan from one simple place.</p>
<div class="hero-actions"><a class="btn" href="books.php">Explore catalog →</a><?php if(empty($_SESSION['user_id'])):?><a class="btn secondary" href="register.php">Create student account</a><?php else:?><a class="btn secondary" href="my_books.php">Open my books</a><?php endif;?></div></div>
<div class="hero-card"><div class="book-art">📚</div><p class="muted">Your library, wherever you study.</p><strong>Search • Request • Read</strong></div></section>
<section class="stats container"><div><strong><?=e($totalBooks)?></strong><span>Titles in catalog</span></div><div><strong><?=e($available)?></strong><span>Copies available</span></div><div><strong><?=e($totalUsers)?></strong><span>Student members</span></div></section>
<section class="container section"><div class="section-head"><div><span class="eyebrow">HOW IT WORKS</span><h2>Everything you need in three steps</h2></div></div><div class="feature-grid">
<article class="feature"><div class="icon">01</div><h3>Discover</h3><p>Search by title, author, category or keyword and open the full book details.</p></article>
<article class="feature"><div class="icon">02</div><h3>Request</h3><p>Sign in and request an available copy. Your request goes straight to the librarian.</p></article>
<article class="feature"><div class="icon">03</div><h3>Track</h3><p>See approvals, due dates, returns and rejected requests from your personal dashboard.</p></article>
</div></section>
<section class="container callout"><div><span class="eyebrow">NEED HELP?</span><h2>Have a question for the library?</h2><p>Send the librarian a message and we’ll have your request recorded.</p></div><a class="btn" href="contact.php">Contact library →</a></section>
</main><footer><span>© <?=date('Y')?> LibraryHub</span><span>College Library Management System</span></footer><script src="script.js"></script></body></html>