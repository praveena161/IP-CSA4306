<?php
require 'database.php';
require_login();

$id=(int)($_POST['id']??$_GET['id']??0);
if($_SERVER['REQUEST_METHOD']==='POST') check_csrf();

$s=$conn->prepare("SELECT id,title,available FROM books WHERE id=?");
$s->bind_param("i",$id);
$s->execute();
$b=$s->get_result()->fetch_assoc();
if(!$b){flash('error','Book not found.');header("Location: books.php");exit;}

$s=$conn->prepare("SELECT id FROM issues WHERE user_id=? AND book_id=? AND status IN ('Pending','Issued')");
$s->bind_param("ii",$_SESSION['user_id'],$id);
$s->execute();
if($s->get_result()->num_rows){flash('error','You already have an active request for this book.');header("Location: my_books.php");exit;}

if($b['available']<1){flash('error','This book is not currently available.');header("Location: book_details.php?id=".$id);exit;}

if($_SERVER['REQUEST_METHOD']!=='POST'){
    header("Location: book_details.php?id=".$id);exit;
}

$issue=date('Y-m-d');
$due=date('Y-m-d',strtotime('+14 days'));
$s=$conn->prepare("INSERT INTO issues(user_id,book_id,issue_date,due_date,status) VALUES(?,?,?,?,'Pending')");
$s->bind_param("iiss",$_SESSION['user_id'],$id,$issue,$due);
if($s->execute()) flash('success','Request submitted. The librarian will review it.');
else flash('error','Could not submit your request.');
header("Location: my_books.php");exit;
