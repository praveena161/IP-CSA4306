LIBRARY MANAGEMENT SYSTEM - UPDATED

INSTALLATION
1. Extract this folder into your XAMPP htdocs directory, for example:
   C:\xampp\htdocs\library_management_system_updated
2. Start Apache and MySQL in XAMPP.
3. Open:
   http://localhost/library_management_system_updated/
4. The application automatically creates the library_db database and required tables.
5. On an empty books table, starter books are inserted automatically.

STUDENT
- Register at /register.php
- Login at /login.php
- Browse /books.php
- Open a book and request it.
- Track Pending / Issued / Returned / Rejected requests in My Books.

ADMIN
- Login at /admin/login.php
- Username: admin
- Password: admin123
- Change the admin password before production deployment.
- Manage books, students, requests/returns and contact messages.

IMPORTANT
- The application expects MySQL at localhost with username root and an empty password,
  which is the default XAMPP setup. If your MySQL credentials differ, edit database.php.
