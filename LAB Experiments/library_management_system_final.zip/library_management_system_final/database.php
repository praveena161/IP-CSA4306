<?php
session_start();
$host="localhost"; $user="root"; $pass=""; $db="library_db";
$conn=new mysqli($host,$user,$pass);
if($conn->connect_error) die("Database connection failed: ".$conn->connect_error);
$conn->query("CREATE DATABASE IF NOT EXISTS `$db`");
$conn->select_db($db); $conn->set_charset("utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
$conn->query("CREATE TABLE IF NOT EXISTS books(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,author VARCHAR(150) NOT NULL,isbn VARCHAR(50),category VARCHAR(100),quantity INT NOT NULL DEFAULT 1,available INT NOT NULL DEFAULT 1,description TEXT)");
$conn->query("CREATE TABLE IF NOT EXISTS issues(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,book_id INT NOT NULL,issue_date DATE NOT NULL,due_date DATE NOT NULL,return_date DATE NULL,status ENUM('Pending','Issued','Returned','Rejected') DEFAULT 'Pending',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE)");
$conn->query("CREATE TABLE IF NOT EXISTS messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$check=$conn->query("SELECT id FROM admins LIMIT 1");
if($check && $check->num_rows===0){$hash=password_hash("admin123",PASSWORD_DEFAULT);$stmt=$conn->prepare("INSERT INTO admins(username,password) VALUES('admin',?)");$stmt->bind_param("s",$hash);$stmt->execute();}

// Seed a starter catalog on a brand-new installation. Existing books are never overwritten.
$bookCheck=$conn->query("SELECT COUNT(*) AS n FROM books");
if($bookCheck && (int)$bookCheck->fetch_assoc()['n']===0){
    $starterBooks=[
        ['Clean Code','Robert C. Martin','9780132350884','Programming',4,'A practical guide to writing readable, maintainable and professional software.'],
        ['The Pragmatic Programmer','Andrew Hunt & David Thomas','9780135957059','Programming',3,'Timeless techniques and practical advice for becoming a better software developer.'],
        ['Introduction to Algorithms','Thomas H. Cormen et al.','9780262046305','Computer Science',3,'A comprehensive introduction to algorithms, data structures and algorithmic problem solving.'],
        ['Computer Networks','Andrew S. Tanenbaum & David J. Wetherall','9780132126953','Computer Science',3,'Core concepts of computer networking, protocols, architectures and communication systems.'],
        ['Database System Concepts','Abraham Silberschatz, Henry Korth & S. Sudarshan','9780078022159','Database',3,'Fundamentals of database design, SQL, transactions, storage and database systems.'],
        ['Operating System Concepts','Abraham Silberschatz, Peter Baer Galvin & Greg Gagne','9781119456339','Operating Systems',3,'Essential operating-system concepts including processes, memory, storage and security.'],
        ['Artificial Intelligence: A Modern Approach','Stuart Russell & Peter Norvig','9780134610993','Artificial Intelligence',2,'A broad introduction to modern artificial intelligence, intelligent agents and machine learning.'],
        ['Engineering Mathematics','John Bird','9781032453194','Mathematics',4,'A student-friendly reference covering algebra, calculus, vectors, differential equations and applied mathematics.'],
        ['Atomic Habits','James Clear','9780735211292','Self Development',3,'A practical framework for building good habits, breaking bad ones and making small improvements consistently.'],
        ['The Alchemist','Paulo Coelho','9780062315007','Fiction',2,'A widely read novel about following a dream, discovering purpose and listening to one’s heart.'],
        ['Rich Dad Poor Dad','Robert T. Kiyosaki','9781612681139','Finance',2,'A personal-finance classic focused on financial education, assets, liabilities and long-term thinking.'],
        ['The Design of Everyday Things','Don Norman','9780465050659','Design',2,'An accessible introduction to human-centered design and creating products that are easier to understand and use.']
    ];
    $stmt=$conn->prepare("INSERT INTO books(title,author,isbn,category,quantity,available,description) VALUES(?,?,?,?,?,?,?)");
    foreach($starterBooks as $book){
        [$title,$author,$isbn,$category,$qty,$description]=$book;
        $available=$qty;
        $stmt->bind_param('ssssiss',$title,$author,$isbn,$category,$qty,$available,$description);
        $stmt->execute();
    }
    $stmt->close();
}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user_id'])){header("Location: login.php?login_required=1");exit;}}
function require_admin(){if(empty($_SESSION['admin_id'])){header("Location: login.php");exit;}}
function csrf_token(){if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf'];}
function check_csrf(){if($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(403);die("Invalid request token.");}}
function flash($type,$message){$_SESSION['flash']=['type'=>$type,'message'=>$message];}
function show_flash(){if(!empty($_SESSION['flash'])){$f=$_SESSION['flash'];unset($_SESSION['flash']);echo '<div class="alert '.e($f['type']).'">'.e($f['message']).'</div>';}}
function active($file){return basename($_SERVER['PHP_SELF'])===$file?'active':'';}
?>