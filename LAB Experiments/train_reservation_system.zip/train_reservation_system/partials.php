<?php
require_once __DIR__.'/config/db.php';
function header_html($title='Railly') {
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=esc($title)?> · Railly</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="top"><a class="brand" href="index.php"><span class="logo">R</span>railly</a><nav>
<a href="index.php">Search</a><a href="trains.php">Trains</a><a href="pnr.php">PNR Status</a><a href="news.php">Updates</a>
<?php if(logged()): ?><a href="dashboard.php">My tickets</a><a href="profile.php">Profile</a><a class="outline" href="logout.php">Logout</a><?php else: ?><a href="login.php">Login</a><a class="btn small" href="register.php">Register</a><?php endif; ?>
<?php if(admin()): ?><a class="adminlink" href="admin/index.php">Admin</a><?php endif; ?>
</nav></header><main>
<?php if(!empty($_SESSION['flash'])) { $f=$_SESSION['flash']; unset($_SESSION['flash']); ?><div class="flash <?=$f['type']?>"><?=esc($f['msg'])?></div><?php } ?>
<?php
}
function footer_html() {
?>
</main><footer><div><strong>railly</strong><p>Simple, clear railway reservation for every journey.</p></div><div><a href="pnr.php">PNR status</a><a href="news.php">Updates</a><a href="admin/login.php">Admin</a></div><p class="copy">© <?=date('Y')?> Railly Reservation</p></footer></body></html>
<?php
}
?>
