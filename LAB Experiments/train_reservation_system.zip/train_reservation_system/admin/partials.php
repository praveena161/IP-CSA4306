<?php
require_once __DIR__.'/../config/db.php';
require_admin();
function ah($title) {
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=esc($title)?> · Railly Admin</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Plus+Jakarta+Sans:wght@700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"></head><body>
<header class="top"><a class="brand" href="index.php"><span class="logo">R</span>railly <small style="color:#2854d8">ADMIN</small></a><nav><a href="../index.php">Site</a><a href="index.php">Dashboard</a><a href="trains.php">Trains</a><a href="classes.php">Classes/Fares</a><a href="bookings.php">Bookings</a><a href="users.php">Users</a><a href="refunds.php">Refunds</a><a href="news.php">News</a><a class="outline" href="../logout.php">Logout</a></nav></header>
<div class="adminnav"><a href="index.php">Overview</a><a href="trains.php">Train details</a><a href="classes.php">Class availability</a><a href="bookings.php">Reservations</a><a href="users.php">Passengers</a><a href="refunds.php">Refund rules</a><a href="reports.php">Reports</a></div><main>
<?php if(!empty($_SESSION['flash'])) { $f=$_SESSION['flash']; unset($_SESSION['flash']); ?><div class="flash <?=$f['type']?>"><?=esc($f['msg'])?></div><?php } ?>
<?php
}
function af() {
?>
</main></body></html>
<?php
}
?>
