<?php
session_start();
$host='localhost';$user='root';$pass='';$db='train_reservation_system';
$conn=@new mysqli($host,$user,$pass);
if($conn->connect_error) die('MySQL connection failed: '.$conn->connect_error);
$conn->set_charset('utf8mb4');
$conn->query("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db($db);
function esc($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function go($u){header("Location: $u");exit;}
function flash($t,$m){$_SESSION['flash']=['type'=>$t,'msg'=>$m];}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function check_csrf(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid request token.');}}
function logged(){return !empty($_SESSION['user']);}
function admin(){return !empty($_SESSION['admin']);}
function require_login(){if(!logged())go('login.php');}
function require_admin(){if(!admin())go('login.php');}
function current_user(){return $_SESSION['user']??null;}
function setup(){
global $conn;
$qs=[
"CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120),email VARCHAR(160) UNIQUE,password VARCHAR(255),phone VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
"CREATE TABLE IF NOT EXISTS trains(id INT AUTO_INCREMENT PRIMARY KEY,number VARCHAR(20),name VARCHAR(150),origin VARCHAR(120),destination VARCHAR(120),departure TIME,arrival TIME,duration VARCHAR(30),running_days VARCHAR(80),image VARCHAR(500),status VARCHAR(20) DEFAULT 'Active')",
"CREATE TABLE IF NOT EXISTS train_classes(id INT AUTO_INCREMENT PRIMARY KEY,train_id INT,class_code VARCHAR(20),class_name VARCHAR(80),fare DECIMAL(10,2),total_seats INT,available_seats INT,FOREIGN KEY(train_id) REFERENCES trains(id) ON DELETE CASCADE)",
"CREATE TABLE IF NOT EXISTS bookings(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,train_id INT,journey_date DATE,pnr VARCHAR(20) UNIQUE,passenger_count INT,class_code VARCHAR(20),passengers TEXT,seat_numbers VARCHAR(255),fare DECIMAL(10,2),payment_mode VARCHAR(20),payment_status VARCHAR(30) DEFAULT 'Paid',status VARCHAR(30) DEFAULT 'CONFIRMED',refund_amount DECIMAL(10,2) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(train_id) REFERENCES trains(id) ON DELETE CASCADE)",
"CREATE TABLE IF NOT EXISTS payments(id INT AUTO_INCREMENT PRIMARY KEY,booking_id INT,amount DECIMAL(10,2),mode VARCHAR(20),transaction_ref VARCHAR(60),status VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE)",
"CREATE TABLE IF NOT EXISTS refund_rules(id INT AUTO_INCREMENT PRIMARY KEY,min_days_before INT,max_days_before INT,refund_percent INT)",
"CREATE TABLE IF NOT EXISTS cancellation_requests(id INT AUTO_INCREMENT PRIMARY KEY,booking_id INT,reason TEXT,requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,status VARCHAR(30) DEFAULT 'Pending',refund_amount DECIMAL(10,2) DEFAULT 0,FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE)",
"CREATE TABLE IF NOT EXISTS news(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200),body TEXT,image VARCHAR(500),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
];foreach($qs as $q)$conn->query($q);
if(!$conn->query("SELECT COUNT(*) n FROM trains")->fetch_assoc()['n']){
$trains=[
['12627','Karnataka Express','New Delhi','Bengaluru','20:20','06:40','34h 20m','Daily','https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=1200'],
['12009','Shatabdi Express','Mumbai','Ahmedabad','06:25','11:05','4h 40m','Mon Tue Wed Thu Fri Sat','https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1200'],
['12839','Chennai Mail','Chennai','Kolkata','23:55','06:45','30h 50m','Daily','https://images.unsplash.com/photo-1531058020387-3be344556be6?w=1200'],
['12245','Duronto Express','Howrah','New Delhi','08:20','17:55','9h 35m','Mon Wed Fri','https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200'],
['12951','Mumbai Rajdhani','Mumbai','New Delhi','17:00','08:35','15h 35m','Daily','https://images.unsplash.com/photo-1500534623283-312aade485b7?w=1200']];
$st=$conn->prepare("INSERT INTO trains(number,name,origin,destination,departure,arrival,duration,running_days,image) VALUES(?,?,?,?,?,?,?,?,?)");
foreach($trains as $x){$st->bind_param("sssssssss",...$x);$st->execute();}
}
if(!$conn->query("SELECT COUNT(*) n FROM train_classes")->fetch_assoc()['n']){
$map=[1,[['SL','Sleeper',520,72],['3A','AC 3 Tier',1350,64],['2A','AC 2 Tier',1950,48],['1A','First AC',3250,24]],
2,[['CC','AC Chair Car',850,78],['EC','Executive Chair',1450,50]],
3,[['SL','Sleeper',600,72],['3A','AC 3 Tier',1550,64],['2A','AC 2 Tier',2250,48]],
4,[['3A','AC 3 Tier',1800,64],['2A','AC 2 Tier',2600,48]],
5,[['3A','AC 3 Tier',1750,64],['2A','AC 2 Tier',2550,48],['1A','First AC',3900,24]]];
$st=$conn->prepare("INSERT INTO train_classes(train_id,class_code,class_name,fare,total_seats,available_seats) VALUES(?,?,?,?,?,?)");
for($i=0;$i<count($map);$i+=2){foreach($map[$i+1] as $c){$a=$c[3];$st->bind_param("issdii",$map[$i],$c[0],$c[1],$c[2],$c[3],$a);$st->execute();}}
}
if(!$conn->query("SELECT COUNT(*) n FROM refund_rules")->fetch_assoc()['n'])$conn->query("INSERT INTO refund_rules(min_days_before,max_days_before,refund_percent) VALUES(30,999,90),(15,29,75),(7,14,50),(3,6,25),(0,2,0)");
if(!$conn->query("SELECT COUNT(*) n FROM news")->fetch_assoc()['n'])$conn->query("INSERT INTO news(title,body,image) VALUES('New timetable update','Check updated departures and plan your journey with confidence.','https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1000'),('Flexible cancellation','Refund percentage is calculated automatically from the admin refund rules.','https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1000')");
}
setup();
?>