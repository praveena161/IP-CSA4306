# Railly Train Reservation System

PHP/MySQL Internet Programming lab project.

## XAMPP
Extract to `C:\xampp\htdocs\train_reservation_system`, start Apache + MySQL, then open:
`http://localhost/train_reservation_system/`

Database and sample trains/classes/refund rules are created automatically.

## Admin
URL: `/admin/login.php`
Email: `admin@railly.local`
Password: `admin123`

## Features
User registration/login/profile, train search, class and seat availability, passenger details, online/offline demo payment, PNR generation/status, printable ticket, booking history, cancellation/refunds, admin train/class/seat/fare management, reservation management, users, refund rules, news and reports.

## Notes
Payment is a local academic demo and does not store card details. Email confirmation is represented in the confirmation/ticket workflow; SMTP can be added for deployment.
