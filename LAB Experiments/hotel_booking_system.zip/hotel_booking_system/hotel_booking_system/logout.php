<?php require 'includes/bootstrap.php';session_destroy();header('Location: index.php');exit;
