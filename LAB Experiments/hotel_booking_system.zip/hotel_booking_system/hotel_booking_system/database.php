<?php
// Hotel Booking System - automatic MySQL setup
$host = 'localhost';
$user = 'root';
$pass = '';
$dbName = 'hotel_booking_system';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_errno) die('Database connection failed: ' . htmlspecialchars($conn->connect_error));
$conn->set_charset('utf8mb4');
$conn->query("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
if (!$conn->select_db($dbName)) die('Unable to select database.');

$tables = [
"CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(30) DEFAULT '', address VARCHAR(255) DEFAULT '', password VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS room_types (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL, slug VARCHAR(80) NOT NULL UNIQUE,
 description TEXT NOT NULL, amenities TEXT NOT NULL, price DECIMAL(10,2) NOT NULL, quantity INT NOT NULL DEFAULT 0,
 max_guests INT NOT NULL DEFAULT 2, image VARCHAR(255) DEFAULT '', updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS bookings (
 id INT AUTO_INCREMENT PRIMARY KEY, booking_code VARCHAR(30) NOT NULL UNIQUE, user_id INT NOT NULL, room_type_id INT NOT NULL,
 check_in DATE NOT NULL, check_out DATE NOT NULL, guests INT NOT NULL, rooms INT NOT NULL DEFAULT 1,
 guest_name VARCHAR(100) NOT NULL, guest_email VARCHAR(190) NOT NULL, guest_phone VARCHAR(30) DEFAULT '', special_request TEXT,
 status ENUM('confirmed','cancelled','completed') NOT NULL DEFAULT 'confirmed', payment_status ENUM('pending','paid','refunded') NOT NULL DEFAULT 'pending',
 payment_reference VARCHAR(100) DEFAULT '', total_amount DECIMAL(10,2) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(room_type_id) REFERENCES room_types(id) ON DELETE RESTRICT,
 INDEX(check_in, check_out), INDEX(user_id), INDEX(status)
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS reviews (
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, room_type_id INT NOT NULL, booking_id INT NOT NULL UNIQUE,
 rating TINYINT NOT NULL, comment TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(room_type_id) REFERENCES room_types(id) ON DELETE CASCADE, FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS pages (
 id INT AUTO_INCREMENT PRIMARY KEY, page_key VARCHAR(60) NOT NULL UNIQUE, title VARCHAR(150) NOT NULL, content LONGTEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB"
];
foreach ($tables as $sql) $conn->query($sql);

$adminEmail = 'admin@hotel.local';
$check = $conn->prepare('SELECT id FROM users WHERE email=?'); $check->bind_param('s',$adminEmail); $check->execute(); $check->store_result();
if ($check->num_rows === 0) {
  $hash = password_hash('admin123', PASSWORD_DEFAULT);
  $s = $conn->prepare("INSERT INTO users(name,email,password,role) VALUES('Hotel Administrator',?,?, 'admin')"); $s->bind_param('ss',$adminEmail,$hash); $s->execute();
}
$rooms = [
 ['Deluxe Room','deluxe','Comfortable room with a king bed, work desk and city view.','King bed, Wi-Fi, Smart TV, Breakfast, Air conditioning, Room service',120,10,2],
 ['Executive Room','executive','Spacious room designed for business and premium leisure stays.','King bed, Wi-Fi, Breakfast, Work desk, Mini bar, City view',165,8,2],
 ['Family Suite','family-suite','Large suite with separate sleeping and living areas for families.','King bed, Sofa bed, Wi-Fi, Breakfast, Living room, Mini fridge',220,6,4],
 ['Presidential Suite','presidential','Luxury suite with premium furnishings and a separate lounge.','King bed, Lounge, Bathtub, Wi-Fi, Breakfast, Airport transfer, Butler service',350,3,4]
];
foreach ($rooms as $r) {
  $q=$conn->prepare('SELECT id FROM room_types WHERE slug=?'); $q->bind_param('s',$r[1]); $q->execute(); $q->store_result();
  if($q->num_rows===0){$i=$conn->prepare('INSERT INTO room_types(name,slug,description,amenities,price,quantity,max_guests) VALUES(?,?,?,?,?,?,?)');$i->bind_param('ssssdii',$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6]);$i->execute();}
}
$pages = [
 ['about','About Us','<h2>Welcome to Grand Horizon Hotel</h2><p>Grand Horizon is a modern city hotel focused on comfortable rooms, friendly service and convenient stays for business and leisure travellers.</p><p>Our team is available around the clock to make every stay simple and memorable.</p>'],
 ['contact','Contact Us','<h2>We are here to help</h2><p><strong>Phone:</strong> +91 98765 43210</p><p><strong>Email:</strong> reservations@grandhorizon.local</p><p><strong>Address:</strong> 12 Central Avenue, Bengaluru, India</p>'],
 ['faq','Customer Service Q&A','<h2>Frequently Asked Questions</h2><h3>What time is check-in?</h3><p>Check-in starts at 2:00 PM and check-out is by 11:00 AM.</p><h3>Can I modify my booking?</h3><p>Confirmed bookings can be changed up to 3 days before check-in, subject to availability.</p><h3>Can I cancel my booking?</h3><p>You can cancel up to 3 days before check-in. Refund handling depends on payment status.</p>'],
 ['travel','Local Travel & Shipping Guide','<h2>Getting Around</h2><p>The hotel is close to public transport, taxi services and major city attractions. Ask the front desk for local recommendations.</p><h3>Airport</h3><p>Pre-booked airport transfers are available on request.</p><h3>Shipping & Deliveries</h3><p>Guests may receive parcels at reception. Please include your booking name and stay dates.</p>'],
 ['privacy','Privacy Policy','<h2>Privacy Policy</h2><p>We collect only the information required to create accounts, process bookings, provide customer service and maintain booking records.</p><p>Passwords are stored using secure one-way hashing. Payment card details are not stored by this demo application.</p>']
];
foreach($pages as $p){$q=$conn->prepare('SELECT id FROM pages WHERE page_key=?');$q->bind_param('s',$p[0]);$q->execute();$q->store_result();if($q->num_rows===0){$i=$conn->prepare('INSERT INTO pages(page_key,title,content) VALUES(?,?,?)');$i->bind_param('sss',$p[0],$p[1],$p[2]);$i->execute();}}
?>
