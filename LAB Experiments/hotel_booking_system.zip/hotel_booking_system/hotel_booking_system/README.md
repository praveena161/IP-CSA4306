# Grand Horizon Hotel Booking System

PHP 8 + MySQL project for XAMPP.

## Setup
1. Extract the folder to `C:\xampp\htdocs\hotel_booking_system`.
2. Start Apache and MySQL in XAMPP.
3. Open `http://localhost/hotel_booking_system/`.
4. The application creates the database `hotel_booking_system` and seed data automatically.

## Admin
- Email: `admin@hotel.local`
- Password: `admin123`

## Included functionality
- User registration/login/profile
- Date + guest + room search
- Four room types with price, quantity, amenities and capacity
- Real availability calculation against overlapping confirmed bookings
- Booking checkout and local demo secure-payment flow
- Booking history
- Modify/cancel up to 3 days before arrival
- Reviews and ratings after completed stays
- Admin room quantity/price management
- Admin booking modification/cancellation/completion
- Admin user list/search
- Admin editing for About, Contact, FAQ, Travel/Shipping and Privacy pages
- Responsive UI

### Payment note
`payment.php` is a local academic/demo payment gateway. It intentionally does not store card numbers. For production, replace it with Stripe/Razorpay/another PCI-compliant hosted checkout using official SDK/API credentials.

### Email note
For a local XAMPP project, PHP `mail()` depends on local SMTP configuration. The booking itself is persisted and confirmed in the dashboard. Production email delivery should be connected to an SMTP/provider such as PHPMailer + authenticated SMTP or a transactional email API.
