<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/../database.php';
if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
function e($v){return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');}
function csrf(){return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">';}
function verify_csrf(){if(!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'],$_POST['csrf'])){http_response_code(419);exit('Invalid security token. Please go back and try again.');}}
function user(){return $_SESSION['user'] ?? null;}
function require_login(){if(!user()){header('Location: login.php?redirect='.urlencode($_SERVER['REQUEST_URI']));exit;}}
function require_admin(){if(!user() || user()['role']!=='admin'){header('Location: ../login.php');exit;}}
function flash($type,$msg){$_SESSION['flash']=['type'=>$type,'msg'=>$msg];}
function show_flash(){if(isset($_SESSION['flash'])){$f=$_SESSION['flash'];unset($_SESSION['flash']);echo '<div class="alert '.e($f['type']).'">'.e($f['msg']).'</div>';}}
function money($v){return '₹'.number_format((float)$v,2);}
function availability($conn,$roomId,$in,$out,$exclude=0){
 $q=$conn->prepare("SELECT quantity-COALESCE(SUM(b.rooms),0) available FROM room_types r LEFT JOIN bookings b ON b.room_type_id=r.id AND b.status='confirmed' AND b.check_in < ? AND b.check_out > ? AND b.id<>? WHERE r.id=? GROUP BY r.id");
 $q->bind_param('ssii',$out,$in,$exclude,$roomId);$q->execute();$row=$q->get_result()->fetch_assoc();return max(0,(int)($row['available']??0));
}
function booking_editable($date){return (strtotime($date.' 00:00:00') - strtotime(date('Y-m-d').' 00:00:00')) >= 3*86400;}
function page_content($conn,$key){$q=$conn->prepare('SELECT title,content FROM pages WHERE page_key=?');$q->bind_param('s',$key);$q->execute();return $q->get_result()->fetch_assoc();}
function layout_header($title){global $conn; $u=user(); ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> · Grand Horizon</title><link rel="stylesheet" href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../assets/style.css':'assets/style.css'?>"></head><body><header class="top"><a class="brand" href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../index.php':'index.php'?>">GRAND <span>HORIZON</span></a><nav><?php if($u): ?><a href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../dashboard.php':'dashboard.php'?>">Dashboard</a><?php endif; ?><a href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../rooms.php':'rooms.php'?>">Rooms</a><a href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../page.php?key=about':'page.php?key=about'?>">About</a><a href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../page.php?key=contact':'page.php?key=contact'?>">Contact</a><?php if($u && $u['role']==='admin'): ?><a href="admin/index.php">Admin</a><?php endif; ?><?php if($u): ?><a class="outline" href="<?=str_contains($_SERVER['PHP_SELF'],'/admin/')?'../logout.php':'logout.php'?>">Logout</a><?php else: ?><a class="outline" href="login.php">Login</a><?php endif; ?></nav></header><main class="container"><?php show_flash(); }
function layout_footer(){ ?><footer><div><strong>Grand Horizon Hotel</strong><p>Comfort, convenience and memorable stays.</p></div><div><a href="page.php?key=faq">FAQ</a><a href="page.php?key=travel">Travel Guide</a><a href="page.php?key=privacy">Privacy Policy</a></div><p>© <?=date('Y')?> Grand Horizon Hotel</p></footer></main></body></html><?php }
?>
