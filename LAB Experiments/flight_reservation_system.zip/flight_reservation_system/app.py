from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import date, timedelta
import sqlite3, os, secrets, csv, io

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-demo-secret-before-deployment")
DB = os.path.join(os.path.dirname(__file__), "flights.db")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS flights(
          id INTEGER PRIMARY KEY AUTOINCREMENT, airline TEXT NOT NULL, flight_no TEXT UNIQUE NOT NULL,
          origin TEXT NOT NULL, destination TEXT NOT NULL, depart_date TEXT NOT NULL,
          depart_time TEXT NOT NULL, arrive_time TEXT NOT NULL, fare_economy REAL NOT NULL,
          fare_business REAL NOT NULL, seats_economy INTEGER NOT NULL, seats_business INTEGER NOT NULL,
          active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS bookings(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
          flight_id INTEGER NOT NULL REFERENCES flights(id), passenger_name TEXT NOT NULL,
          passenger_email TEXT NOT NULL, passenger_phone TEXT NOT NULL, travel_class TEXT NOT NULL,
          seat_no TEXT NOT NULL, amount REAL NOT NULL, status TEXT NOT NULL DEFAULT 'CONFIRMED',
          payment_ref TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS feedback(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id),
          name TEXT NOT NULL, message TEXT NOT NULL, rating INTEGER NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        admin = con.execute("SELECT id FROM users WHERE username='admin'").fetchone()
        if not admin:
            con.execute("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)",
                        ("admin","admin@example.com",generate_password_hash("admin123"),"admin"))
        count = con.execute("SELECT COUNT(*) n FROM flights").fetchone()["n"]
        if count == 0:
            today = date.today()
            demo = [
              ("SkyWays","SW101","Chennai","Delhi",0,"06:30","09:25",5200,12500,24,8),
              ("SkyWays","SW205","Chennai","Mumbai",0,"10:15","12:10",4100,9900,30,6),
              ("AirNova","AN311","Chennai","Bengaluru",0,"14:00","15:05",2200,6200,28,6),
              ("AirNova","AN408","Delhi","Chennai",1,"18:20","21:15",5600,13200,20,5),
              ("SkyWays","SW509","Mumbai","Delhi",2,"08:45","10:55",3900,8700,26,7),
              ("AirNova","AN620","Bengaluru","Chennai",3,"16:30","17:35",2100,6000,22,5),
            ]
            for a,n,o,d,off,dt,at,fe,fb,se,sb in demo:
                con.execute("""INSERT INTO flights(airline,flight_no,origin,destination,depart_date,depart_time,arrive_time,
                fare_economy,fare_business,seats_economy,seats_business) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (a,n,o,d,(today+timedelta(days=off)).isoformat(),dt,at,fe,fb,se,sb))

def current_user():
    if "user_id" not in session: return None
    with db() as con:
        return con.execute("SELECT id,username,email,role FROM users WHERE id=?", (session["user_id"],)).fetchone()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "error")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        u=current_user()
        if not u or u["role"]!="admin":
            flash("Administrator access is required.", "error")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_user():
    return {"user": current_user(), "today": date.today().isoformat()}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        if len(username)<3 or "@" not in email or len(password)<6:
            flash("Enter a username (3+ characters), valid email, and password (6+ characters).","error")
        else:
            try:
                with db() as con:
                    con.execute("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)",
                                (username,email,generate_password_hash(password)))
                flash("Registration successful. Please log in.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email already exists.","error")
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        key=request.form.get("username","").strip()
        password=request.form.get("password","")
        with db() as con:
            u=con.execute("SELECT * FROM users WHERE username=? OR email=?",(key,key.lower())).fetchone()
        if u and check_password_hash(u["password_hash"],password):
            session.clear(); session["user_id"]=u["id"]
            flash("Welcome back!","success")
            target=request.args.get("next")
            return redirect(target if target and target.startswith("/") else url_for("admin" if u["role"]=="admin" else "dashboard"))
        flash("Incorrect username/email or password.","error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); flash("You have logged out.","success")
    return redirect(url_for("index"))

@app.route("/forgot-password", methods=["GET","POST"])
def forgot_password():
    reset_code=None
    if request.method=="POST":
        email=request.form.get("email","").strip().lower()
        with db() as con:
            u=con.execute("SELECT id FROM users WHERE email=?",(email,)).fetchone()
            if u:
                # Local lab demo only: one-time token displayed on screen, not sent by email.
                token=secrets.token_urlsafe(18)
                con.execute("CREATE TABLE IF NOT EXISTS reset_tokens(token TEXT PRIMARY KEY,user_id INTEGER,expires_at TEXT)")
                con.execute("DELETE FROM reset_tokens WHERE user_id=?",(u["id"],))
                con.execute("INSERT INTO reset_tokens(token,user_id,expires_at) VALUES(?,?,datetime('now','+20 minutes'))",(token,u["id"]))
                reset_code=token
        flash("If that email is registered, a demo reset token is shown below.","success")
    return render_template("forgot.html", reset_code=reset_code)

@app.route("/reset-password", methods=["GET","POST"])
def reset_password():
    token=request.values.get("token","").strip()
    if request.method=="POST":
        password=request.form.get("password","")
        with db() as con:
            row=con.execute("SELECT user_id FROM reset_tokens WHERE token=? AND expires_at>datetime('now')",(token,)).fetchone()
            if row and len(password)>=6:
                con.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(password),row["user_id"]))
                con.execute("DELETE FROM reset_tokens WHERE token=?",(token,))
                flash("Password updated. Please log in.","success")
                return redirect(url_for("login"))
        flash("Reset token is invalid/expired, or password is too short.","error")
    return render_template("reset.html",token=token)

@app.route("/search", methods=["GET","POST"])
def search():
    origin=request.values.get("origin","").strip()
    destination=request.values.get("destination","").strip()
    depart_date=request.values.get("depart_date",date.today().isoformat())
    travel_class=request.values.get("travel_class","Economy")
    results=[]
    if origin and destination and origin.lower()!=destination.lower():
        with db() as con:
            flights=con.execute("""SELECT * FROM flights WHERE active=1 AND lower(origin)=lower(?)
              AND lower(destination)=lower(?) AND depart_date=? ORDER BY depart_time""",
              (origin,destination,depart_date)).fetchall()
            for f in flights:
                col="seats_business" if travel_class=="Business" else "seats_economy"
                used=con.execute("SELECT COUNT(*) n FROM bookings WHERE flight_id=? AND travel_class=? AND status='CONFIRMED'",
                                 (f["id"],travel_class)).fetchone()["n"]
                available=max(0,f[col]-used)
                results.append({"flight":f,"available":available,"fare":f["fare_business"] if travel_class=="Business" else f["fare_economy"]})
    elif origin and destination:
        flash("Origin and destination must be different.","error")
    return render_template("search.html",results=results,origin=origin,destination=destination,depart_date=depart_date,travel_class=travel_class)

@app.route("/book/<int:flight_id>", methods=["GET","POST"])
@login_required
def book(flight_id):
    travel_class=request.values.get("travel_class","Economy")
    if travel_class not in ("Economy","Business"): travel_class="Economy"
    with db() as con:
        f=con.execute("SELECT * FROM flights WHERE id=? AND active=1",(flight_id,)).fetchone()
        if not f: flash("Flight not found.","error"); return redirect(url_for("search"))
        col="seats_business" if travel_class=="Business" else "seats_economy"
        used=con.execute("SELECT COUNT(*) n FROM bookings WHERE flight_id=? AND travel_class=? AND status='CONFIRMED'",(flight_id,travel_class)).fetchone()["n"]
        available=max(0,f[col]-used)
    if request.method=="POST":
        name=request.form.get("passenger_name","").strip()
        email=request.form.get("passenger_email","").strip()
        phone=request.form.get("passenger_phone","").strip()
        seat=request.form.get("seat_no","").strip().upper()
        expected=f["fare_business"] if travel_class=="Business" else f["fare_economy"]
        allowed=[f"{'B' if travel_class=='Business' else 'E'}{i:02d}" for i in range(1,f[col]+1)]
        if not name or "@" not in email or len(phone)<7 or seat not in allowed:
            flash("Enter valid passenger details and select a listed seat.","error")
        else:
            with db() as con:
                # Check again immediately before booking to avoid double allocation in the demo.
                already=con.execute("SELECT id FROM bookings WHERE flight_id=? AND travel_class=? AND seat_no=? AND status='CONFIRMED'",(flight_id,travel_class,seat)).fetchone()
                used=con.execute("SELECT COUNT(*) n FROM bookings WHERE flight_id=? AND travel_class=? AND status='CONFIRMED'",(flight_id,travel_class)).fetchone()["n"]
                if already or used>=f[col]:
                    flash("That seat is no longer available. Please choose another seat.","error")
                else:
                    ref="DEMO-"+secrets.token_hex(4).upper()
                    cur=con.execute("""INSERT INTO bookings(user_id,flight_id,passenger_name,passenger_email,passenger_phone,
                    travel_class,seat_no,amount,payment_ref,status) VALUES(?,?,?,?,?,?,?,?,?,'PENDING')""",
                    (session["user_id"],flight_id,name,email,phone,travel_class,seat,expected,ref))
                    booking_id=cur.lastrowid
                    return redirect(url_for("payment",booking_id=booking_id))
    taken=[]
    with db() as con:
        taken=[r["seat_no"] for r in con.execute("SELECT seat_no FROM bookings WHERE flight_id=? AND travel_class=? AND status='CONFIRMED'",(flight_id,travel_class)).fetchall()]
    seats=[{"seat":f"{'B' if travel_class=='Business' else 'E'}{i:02d}","taken":f"{'B' if travel_class=='Business' else 'E'}{i:02d}" in taken} for i in range(1,f[col]+1)]
    return render_template("book.html",flight=f,travel_class=travel_class,available=available,seats=seats)

@app.route("/payment/<int:booking_id>", methods=["GET","POST"])
@login_required
def payment(booking_id):
    with db() as con:
        b=con.execute("SELECT b.*,f.airline,f.flight_no,f.origin,f.destination,f.depart_date,f.depart_time,f.arrive_time FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.id=? AND b.user_id=?",(booking_id,session["user_id"])).fetchone()
    if not b: flash("Booking not found.","error"); return redirect(url_for("dashboard"))
    if request.method=="POST":
        if b["status"] == "PENDING":
            with db() as con:
                con.execute("UPDATE bookings SET status='CONFIRMED' WHERE id=? AND user_id=? AND status='PENDING'", (booking_id, session["user_id"]))
            flash("Demo payment approved and ticket confirmed. No real money was charged.","success")
        else:
            flash("This booking has already been processed. No real money was charged.","success")
        return redirect(url_for("ticket",booking_id=booking_id))
    return render_template("payment.html",booking=b)

@app.route("/dashboard")
@login_required
def dashboard():
    with db() as con:
        bookings=con.execute("""SELECT b.*,f.airline,f.flight_no,f.origin,f.destination,f.depart_date,f.depart_time
          FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.user_id=? ORDER BY b.id DESC""",(session["user_id"],)).fetchall()
    return render_template("dashboard.html",bookings=bookings)

@app.route("/ticket/<int:booking_id>")
@login_required
def ticket(booking_id):
    with db() as con:
        b=con.execute("""SELECT b.*,f.airline,f.flight_no,f.origin,f.destination,f.depart_date,f.depart_time,f.arrive_time
        FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.id=? AND (b.user_id=? OR ?='admin')""",
        (booking_id,session["user_id"],current_user()["role"])).fetchone()
    if not b: flash("Ticket not found.","error"); return redirect(url_for("dashboard"))
    return render_template("ticket.html",booking=b)

@app.route("/cancel/<int:booking_id>",methods=["POST"])
@login_required
def cancel(booking_id):
    with db() as con:
        b=con.execute("SELECT * FROM bookings WHERE id=? AND user_id=?",(booking_id,session["user_id"])).fetchone()
        if not b: flash("Booking not found.","error")
        elif b["status"]=="CANCELLED": flash("Ticket is already cancelled.","error")
        else:
            con.execute("UPDATE bookings SET status='CANCELLED' WHERE id=?",(booking_id,))
            flash("Ticket cancelled. Demo system does not process real refunds.","success")
    return redirect(url_for("dashboard"))

@app.route("/feedback",methods=["GET","POST"])
def feedback():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        message=request.form.get("message","").strip()
        try: rating=int(request.form.get("rating","5"))
        except ValueError: rating=5
        if name and message and 1<=rating<=5:
            with db() as con: con.execute("INSERT INTO feedback(user_id,name,message,rating) VALUES(?,?,?,?)",
              (session.get("user_id"),name,message,rating))
            flash("Thank you for your feedback!","success"); return redirect(url_for("feedback"))
        flash("Please complete all fields and choose a rating from 1 to 5.","error")
    return render_template("feedback.html")

@app.route("/admin")
@admin_required
def admin():
    with db() as con:
        flights=con.execute("SELECT * FROM flights ORDER BY depart_date,depart_time").fetchall()
        bookings=con.execute("""SELECT b.*,u.username,f.flight_no,f.origin,f.destination FROM bookings b
          JOIN users u ON u.id=b.user_id JOIN flights f ON f.id=b.flight_id ORDER BY b.id DESC LIMIT 100""").fetchall()
        users=con.execute("SELECT id,username,email,role,created_at FROM users ORDER BY id").fetchall()
        feedbacks=con.execute("SELECT * FROM feedback ORDER BY id DESC").fetchall()
        stats={"flights":con.execute("SELECT COUNT(*) n FROM flights WHERE active=1").fetchone()["n"],
          "bookings":con.execute("SELECT COUNT(*) n FROM bookings WHERE status='CONFIRMED'").fetchone()["n"],
          "users":len(users),"revenue":con.execute("SELECT COALESCE(SUM(amount),0) n FROM bookings WHERE status='CONFIRMED'").fetchone()["n"]}
    return render_template("admin.html",flights=flights,bookings=bookings,users=users,feedbacks=feedbacks,stats=stats)

@app.route("/admin/flight",methods=["POST"])
@admin_required
def add_flight():
    try:
        data=(request.form["airline"].strip(),request.form["flight_no"].strip().upper(),request.form["origin"].strip(),
        request.form["destination"].strip(),request.form["depart_date"],request.form["depart_time"],request.form["arrive_time"],
        float(request.form["fare_economy"]),float(request.form["fare_business"]),int(request.form["seats_economy"]),int(request.form["seats_business"]))
        if not all(data[:7]) or data[2].lower()==data[3].lower() or min(data[7],data[8])<0 or min(data[9],data[10])<1: raise ValueError()
        with db() as con:
            con.execute("""INSERT INTO flights(airline,flight_no,origin,destination,depart_date,depart_time,arrive_time,
            fare_economy,fare_business,seats_economy,seats_business) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",data)
        flash("Flight added successfully.","success")
    except (ValueError,KeyError,sqlite3.IntegrityError):
        flash("Could not add flight. Check all values and ensure flight number is unique.","error")
    return redirect(url_for("admin")+"#flights")

@app.route("/admin/flight/<int:fid>/toggle",methods=["POST"])
@admin_required
def toggle_flight(fid):
    with db() as con:
        con.execute("UPDATE flights SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(fid,))
    flash("Flight status updated.","success")
    return redirect(url_for("admin")+"#flights")

@app.route("/admin/report.csv")
@admin_required
def report():
    out=io.StringIO(); writer=csv.writer(out)
    writer.writerow(["Booking ID","Username","Flight","Route","Date","Passenger","Class","Seat","Amount","Status","Payment Ref"])
    with db() as con:
        rows=con.execute("""SELECT b.id,u.username,f.flight_no,f.origin||' - '||f.destination,f.depart_date,b.passenger_name,
        b.travel_class,b.seat_no,b.amount,b.status,b.payment_ref FROM bookings b JOIN users u ON u.id=b.user_id JOIN flights f ON f.id=b.flight_id ORDER BY b.id""").fetchall()
        writer.writerows([tuple(r) for r in rows])
    response=make_response(out.getvalue())
    response.headers["Content-Type"]="text/csv; charset=utf-8"
    response.headers["Content-Disposition"]="attachment; filename=flight_booking_report.csv"
    return response

@app.route("/status",methods=["GET","POST"])
@login_required
def status():
    result=None
    if request.method=="POST":
        try: bid=int(request.form.get("booking_id",""))
        except ValueError: bid=-1
        with db() as con:
            result=con.execute("""SELECT b.*,f.flight_no,f.airline,f.origin,f.destination,f.depart_date,f.depart_time
            FROM bookings b JOIN flights f ON f.id=b.flight_id WHERE b.id=? AND b.user_id=?""",(bid,session["user_id"])).fetchone()
        if not result: flash("No booking found with that ID in your account.","error")
    return render_template("status.html",booking=result)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
