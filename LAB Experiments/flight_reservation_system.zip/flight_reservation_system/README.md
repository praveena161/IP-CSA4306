# Online Flight Reservation System (Internet Programming Lab)

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Start the app: `python app.py`
5. Open `http://127.0.0.1:5000`

## Demo accounts
- Admin: `admin` / `admin123`
- Customer: register a new account from the website.

## Included working features
- Register/login/logout, forgot-password demo flow
- Search flights by origin, destination, date, and class
- Seat availability and seat selection
- Passenger details and demo checkout
- My Tickets, booking status, print ticket, cancellation
- Customer feedback
- Admin dashboard: add flights, manage schedules/fares/capacity, view bookings/users/feedback, CSV report export
- Responsive UI

## Important demo limitations
This is a local educational prototype. It uses SQLite and a simulated payment step; it does **not** charge real cards, send actual emails, connect to airline/GDS inventory, or provide production-grade account recovery. Never enter real payment-card details. The forgot-password page displays a demo reset link/code on-screen. Passwords are hashed. Before real deployment, add verified email delivery, a real payment provider, CSRF protection, rate limiting, secure session configuration, audit logging, and appropriate privacy/security review.
